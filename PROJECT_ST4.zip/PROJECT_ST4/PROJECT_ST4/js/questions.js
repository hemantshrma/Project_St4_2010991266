
let questions = [
    {
    numb: 1,
    question: "What is CSS stands for ?",
    answer: "Cascading Style Sheets",
    options: [
      "Cascading Style Sheets",
      "Cascade Style Sheets",
      "Color Style Sheets",
      "None of these"
    ]
  },
    {
    numb: 2,
    question: "What CSS describes??",
    answer: "CSS describes how HTML elements are to be displayed on screen, paper, or in other media",
    options: [
      "CSS describes how calculation perform on button click.",
      "CSS describes how HTML elements are to be displayed on screen, paper, or in other media",
      "Both A and B",
      "None of the above"
    ]
  },
    {
    numb: 3,
    question: "What is a CSS selector?",
    answer: "A CSS selector is the first part of a CSS Rule. It may an HTML element or pattern of elements.",
    options: [
      "A CSS selector is the CSS class name",
      "A CSS selector is the set of properties that are going to be applied on HTML elements",
      "A CSS selector is name of CSS file",
      "A CSS selector is the first part of a CSS Rule. It may an HTML element or pattern of elements."
    ]
  },
    {
    numb: 4,
    question: "Which of the following is not a Javascript framework?",
    answer: "Cassandra",
    options: [
      "Node",
      "Vue",
      "React",
      "Cassandra"
    ]
  },
    {
    numb: 5,
    question: "In JavaScript the x===y statement implies that:",
    answer: "Both are equal in the value and data type",
    options: [
      "Both x and y are equal in value, type and reference address as well",
      "Both are x and y are equal in value only",
      "Both are equal in the value and data type",
      "Both are not same at all"
    ]
  },
  

     {
     numb: 6,
     question: "Choose the correct snippet from the following to check if the variable 'a' is not equal the 'NULL':",
     answer: "if(a!==null)",
     options: [
       "if(a!==null)",
       "if (a!)",
       "if(a!null)",
       "if(a!=null)"
     ]
   },
   {
    numb: 7,
    question: "Inline styles are written within the _____ attribute.",
    answer: "Style",
    options: [
      "Style",
      "stylesheet",
      "CSS",
      "Both Aand B"
    ]
  },

   {
    numb: 8,
    question: "In JavaScript, single line comment begins with _______.",
    answer: "//",
    options: [
      "#",
      "/*",
      "$",
      "//"
    ]
  },
  {
    numb: 9,
    question: "Which property is used to define the font of the element's text?",
    answer: "font-family",
    options: [
      "font",
      "font-family",
      "font-style",
      "All of the above"
    ]
  },
  {
    numb: 10,
    question: "JavaScript arrays are written with _______.",
    answer: "square brackets []",
    options: [
      "round brackets ()",
      "single quotes '' ",
      "curly brackets {}",
      "square brackets []"
    ]
  },

];